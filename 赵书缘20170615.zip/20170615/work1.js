/**
 * Created by WangJingJing on 2017/6/17.
 */
function calculator(){
    var fn=document.getElementById("first").value;
    var  sn=document.getElementById("second").value;
    if (isNaN(fn) || isNaN(sn)) {
        alert("FirstNumber����SecondNumber����һ����ֵ");
        return;
    }
    var r=0;
    var opt=document.getElementById("sel").value;
    switch(opt){
        case "+":{
            r=Number(fn)+Number(sn)
            alert(r)
            break;
        }
        case "-":{
            r=Number(fn)-Number(sn)
            alert(r)
            break;
        }
        case "*":{
            r=Number(fn)*Number(sn)
            alert(r)
            break;
        }
        case "/":{
            r=Number(fn)/Number(sn)
            alert(r)
            break;
        }
    }
    var result=document.getElementById("result");
    result.innerHTML=r+"";
    result.style.color="blue";
    result.style.fontWeight="bold";
}
