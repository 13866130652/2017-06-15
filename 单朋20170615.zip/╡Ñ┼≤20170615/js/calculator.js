/**
 * Created by Administrator on 2017/6/16.
 */
function First(t){
    var value= t.value;
    if(value==''){
        alert("输入的内容不能为空");
    }
}
function op(t){
    var value= t.value;
    if(value==0){
        alert("请选择正确的操作符");
    }
}
function sub1(){
    var fs=document.getElementById("f").value;
    var f=parseInt(fs);
    var ss=document.getElementById("s").value;
    var s=parseInt(ss);
    var op=document.getElementById("op").value;
    var re=0;
    if(!isNaN(fs)&&!isNaN(ss)&&op!="0") {
        switch (op) {
            case "+":
                re = f + s;
                break;
            case "-":
                re = f - s;
                break;
            case "*":
                re = f * s;
                break;
            case "/":
                re = f / s;
                break;
        }
        alert(re);
        var result = document.getElementById("result").innerHTML = re + '';
    }else{
        alert("First Number或者Second Number不是一个数字或者运算符选择错误");
    }
}