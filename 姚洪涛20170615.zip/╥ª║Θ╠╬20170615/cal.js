function calculate(){
	var num1=parseInt(document.getElementById("first").value);
	var num2=parseInt(document.getElementById("second").value);
	if(isNaN(num1)||isNaN(num2)){
		alert("请输入一个整形数值!");
	}else {
		alert("输入的是整形数值");
	}
	var select=document.getElementById("select").value;
	var result;
	switch(select){
		case "+":
			result=num1+num2;
		break;
		case "-":
			result=num1-num2;
		break;
		case "*":
			result=num1*num2;
		break;
		case "/":
			result=num1/num2;
		break;
		default:
			alert("选择有误!");
		break;
	}
	alert("结果是:"+result);
	document.getElementById("third").value=result;
	
}
