function jisuan(){
	var num1=document.getElementById("ip1").value;
	var suanfu=document.getElementById("option").value;
	var num2=document.getElementById("ip2").value;
	if(isNaN(num1) || isNaN(num2)){
		alert("FirstNum 或者SecondNum不是数字！");
	}
	if(suanfu==""){
		alert("请选择运算类型！");
	}else{
		var num11=parseFloat(num1);
		var num22=parseFloat(num2);
		var result=0;
		switch (suanfu){
			case '+':
				result=num11+num22;
				break;
			case '-':
				result=num11-num22;
				break;
			case '*':
				result=num11*num22;
				break;
			case '/':
				result=num11/num22;
				break;
		}
		var sp=document.getElementById("sp2");
		sp.innerHTML=result;
	}
}
