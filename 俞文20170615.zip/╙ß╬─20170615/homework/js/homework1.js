function js(){
//	alert("1")
	var number1;
	var number2;
	var fuHao;
	var result;
	number1=document.getElementById("first").value;
	number2=document.getElementById("second").value;
	fuHao=document.getElementById("fuHao").value;
	
	switch(fuHao){
		case "+":result=Number(number1)+Number(number2);break;
		case "-":result=Number(number1)-Number(number2);break;
		case "*":result=Number(number1)*Number(number2);break;
		case "/":result=Number(number1)/Number(number2);break;		
	}
	
	document.getElementById("span1").innerHTML=result;
//	alert("1")
}
