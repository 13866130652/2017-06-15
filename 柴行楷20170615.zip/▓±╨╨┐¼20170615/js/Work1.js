/**
 * Created by er on 2017/6/18.
 */
function calculator(){
    var n1=parseFloat(document.getElementById("firstnum").value);
    var n2=parseFloat(document.getElementById("secondnum").value);
    if(isNaN(n1)||isNaN(n2)){
        alert("请输入数字！")
    }
    var op=document.getElementById("option").value;
    var result;
    switch(op){
        case "+":{
            result=n1+n2;
            break;
        }
        case "-":{
            result=n1-n2;
            break;
        }
        case "*":{
            result=n1*n2;
            break;
        }
        case "/":{
            result=n1/n2;
            break;
        }
        default:{
            alert("运算符选择有误！");
            break;
        }
    }
    document.getElementById("result").value=result;
    alert("运算结果是："+result);
}