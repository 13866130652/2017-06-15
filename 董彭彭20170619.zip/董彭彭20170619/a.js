﻿function validateForm() {
    var x = document.forms["myForm"]["nn"].value;
    var t = document.getElementsByClassName("love");
    if (x == null || x == "") {
        t.innerHTML = "必须填写";
        return false;
    }
    else if (isNaN(x)) {
        t.innerHTML = "数字";
        return false;
    }
    else return true;
}
function check1() {
    var x1 = document.getElementById("one").value;
    var x2 = document.getElementById("one");
    var x3 = document.getElementById("one_s");
    var y1 = document.getElementById("tone");
    if (x1 == null || x1 == "") {
        y1.innerHTML = "必须填写！";
        x2.style.borderColor = "#f00";
        x3.style.borderColor = "#f00";
        y1.style.color = "#f00";
        return false;
    }
    else if (isNaN(x1)) {
        y1.innerHTML = "必须是数字！";
        x2.style.borderColor = "#f00";
        x3.style.borderColor = "#f00";
        y1.style.color = "#f00";
        return false;
    }
    else {
        y1.innerHTML = "...";
        x2.style.borderColor = "#cfcfcf";
        x3.style.borderColor = "#cfcfcf";
        y1.style.color = "#cfcfcf";
        return true;
    }
}
function check2() {
    var x2 = document.getElementById("three").value;
    var x1 = document.getElementById("three");
    var x3 = document.getElementById("three_s");
    var y2 = document.getElementById("tore");
    if (x2 == null || x2 == "") {
        y2.innerHTML = "必须填写！";
        x1.style.borderColor = "#f00";
        x3.style.borderColor = "#f00";
        y2.style.color = "#f00";
        return false;
    }
    else if (isNaN(x2)) {
        y2.innerHTML = "必须是数字！";
        x1.style.borderColor = "#f00";
        x3.style.borderColor = "#f00";
        y2.style.color = "#f00";
        return false;
    }
    else {
        y2.innerHTML = "...";
        x1.style.borderColor = "#cfcfcf";
        x3.style.borderColor = "#cfcfcf";
        y2.style.color = "#cfcfcf";
        return true;
    }
}
function calculator() {
    var y1;
    var x1 = document.getElementById("one").value;
    var x2 = document.getElementById("three").value;
    var t = document.getElementById("select").value;
    var y2 = document.getElementById("result");
    if (check1() && check2()) {
        switch (t) {
            case "+":
                y1 = Number(x1) + Number(x2);
                break;
            case "-":
                y1 = x1 - x2;
                break;
            case "*":
                y1 = x1 * x2;
                break;
            case "/":
                y1 = x1 / x2;
                break;
        }
        y2.innerHTML = y1;
    } else {

    }


}