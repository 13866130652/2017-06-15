/**
 * Created by zshock on 2017/6/19.
 */
    function getResult(){
    var f = document.getElementById("firstNum").value;
    var s = document.getElementById("secondNum").value;
    var o = document.getElementById("type").value;
    var r;
    if(isNaN(f)){
        alert("first is not num");
        return;
    }
    if(isNaN(s)){
        alert("second is not num");
        return;
    }
    if(o=="��ѡ�����"){
        alert("�����ѡ�������")
        return;
    }
    switch (o){
        case "+":r=parseInt(f)+parseInt(s);
            break;
        case "-":r=parseInt(f)-parseInt(s);break;
        case "*":r=parseInt(f)*parseInt(s);break;
        case "/":r=parseInt(f)/parseInt(s);break;
    }
    var rt = document.getElementById("res");
    rt.innerHTML=r;
}

