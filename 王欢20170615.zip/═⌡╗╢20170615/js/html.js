/**
 * Created by Huan_Wang on 2017/6/19.
 */

function jisuan(){
    var first=document.getElementById("one").value;
    var second=document.getElementById("two").value;
    if(isNaN(first)||isNaN(second)){
        alert("First Number或者Second Number不是一个数值");
        return;
    }
    var a=0;
    var b=document.getElementById("op").value;
    switch (b){
        case "+":{
            a=Number(first)+Number(second);
            alert(a);
            break;
        }
        case "-":{
            a=Number(first)-Number(second);
            alert(a);
            break;
        }
        case "*":{
            a=Number(first)*Number(second);
            alert(a);
            break;
        }
        case "/":{
            a=Number(first)/Number(second);
            alert(a);
            break;
        }
    }
    var c=document.getElementById("result");
    c.innerHTML=a+"";
}