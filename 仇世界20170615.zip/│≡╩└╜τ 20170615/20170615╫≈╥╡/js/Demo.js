/**
 * Created by Administrator on 2017/6/16 0016.
 */
function myfunction(){
    var x=document.getElementById("fir").value;
    var y=document.getElementById("sec").value;
    if(isNaN(x)||isNaN(y)){
        alert("First Number或者Second Number不是一个值");
        return;
    }
    var op=document.getElementById("opt").value;
    var z=0;
    switch(op){
        case "+":{
            z=Number(x)+Number(y);
            alert(z);
            break;
        }
        case "-":{
            z=Number(x)-Number(y);
            alert(z);
            break;
        }
        case "*":{
            z=Number(x)*Number(y);
            alert(z);
            break;
        }
        case "/":{
            z=Number(x)/Number(y);
            alert(z);
            break;
        }
        case "%":{
            z=Number(x)%Number(y);
            alert(z);
            break;
        }
    }
    var re=document.getElementById("result");
    re.innerHTML=z+"";
    re.style.color="blue";
    re.style.fontWeight="bold";
}
