function count(){
	var results;
	var ff=document.getElementById("fn").value;
	var ss=document.getElementById("sn").value;
	var f=parseInt(ff);
	var s=parseInt(ss);
	var obj = document.getElementById("sele"); //定位id
	var index = obj.value; 

	switch(index){
		case"+":{
			results=f+s;
			break;
		}
		case "-":{
			results=f-s;
			break;
		}
		case "*":{
			results=f*s;
			break;
		}
		case "/":{
			results=f/s;
			break;
		}
	}	
	if(!isNaN(ff)&&!isNaN(ss)){
		alert(results);
		var r=document.getElementById("res");
		r.innerHTML=results+'';
	}
}
