/**
 * Created by asus-xg on 2017/6/15.
 */
function  check(t) {
    var result1 = t.value;
    var sp = document.getElementById("firsts");
    if (result1 == "") {
        sp.innerHTML = "输入框不能为空！";
        sp.style.color = "red";
        sp.style.textAlign="center";
    } else if (isNaN(result1)) {
        sp.innerHTML = "First Number不是一个数值！";
        sp.style.color = "red";
    }
}
function  checks(t) {
    var result2 = t.value;
    var sp = document.getElementById("seconds");
    if (result2 == "") {
        sp.innerHTML = "输入框不能为空！";
        sp.style.color = "red";
        sp.style.textAlign="center";
    } else if (isNaN(result2)) {
        sp.innerHTML = "Second Number不是一个数值！";
        sp.style.color = "red";
    }
}
function count() {
    //var result = "";
    //var sp = document.getElementById("options");
    //var sps = document.getElementById("result");

    var firstValue = document.getElementById("first").value;
    var secondValue = document.getElementById("second").value;
    var thirdValue = document.getElementById("result");
    var selectValue = document.getElementById("option").value;
    switch (selectValue){
        case "+":{
            thirdValue.value = parseInt(firstValue)+parseInt(secondValue);
            break;
        }
        case "-":{
            thirdValue.value = parseInt(firstValue)-parseInt(secondValue);
            break;
        }
        case "*":{
            thirdValue.value = parseInt(firstValue)*parseInt(secondValue);
            break;
        }
        case "/":{
            thirdValue.value = parseInt(firstValue)/parseInt(secondValue);
            break;
        }
    }
    //switch (resultx){
    //    case "+":{
    //        result=result1+result2;
    //        break;
    //    }
    //    case "-":{
    //        result=result1-result2;
    //        break;
    //    }
    //    case "*":{
    //        result=result1*result2;
    //        sps.innerHTML = result;
    //        break;
    //    }
    //    case "/":{
    //        result=result1/result2;
    //        break;
    //    }
    //    default:{
    //        sp.innerHTML = "请重新选择！";
    //        sp.style.color = "red";
    //        sp.style.textAlign="center";
    //        break;
    //    }
    //}
}


